
## Exercicio 1
```shell
faça um programa que leia 5 nomes
depois mostre os 5 nomes na tela
```

## Exercicio 2
```shell
Danilo, professor de programação está precisando de um software para
cadastrar os seus alunos e dar as notas respectivas para cada aluno
e depois calcular a média para saber se estes alunos estão aprovados ou reprovados.
Faça um programa que cadastre:
1 - alunos
2 - notas dos alunos
3 - mostre se o aluno está aprovado ou reprovado

Regra de aprovação:
Notas abaixo de 5 = reprovado
Notas entre 5 e 6,9 = recuperação
Notas 7 ou acima = Aprovado

Mostre uma opção para vermos o relatório dos alunos cadastrados
```