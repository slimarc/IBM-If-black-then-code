./build.sh
./run.sh