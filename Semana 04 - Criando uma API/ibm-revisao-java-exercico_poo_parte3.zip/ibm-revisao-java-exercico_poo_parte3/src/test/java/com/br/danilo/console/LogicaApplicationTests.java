package com.br.danilo.console;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LogicaApplicationTests {

	@Test
	void contextLoads() {
	}

}
