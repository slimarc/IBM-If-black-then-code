mvn clean
mvn package